'use strict';
const { DataTypes, Model } = require('sequelize');
const sequelize = require("./../../database/config/sequelize.js");
const RoleValidator = require("./../validators/roles.validator.js");

class Role extends Model { }
Role.init({
	id: {
		type: DataTypes.INTEGER,
		autoIncrement: true,
		primaryKey: true
	},
	name: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: RoleValidator.name
	},
	description: {
		type: DataTypes.STRING,
		validate: RoleValidator.description
	},
	notes: {
		type: DataTypes.STRING,
		validate: RoleValidator.notes
	}
}, {
	sequelize,
	modelName: 'Role',
	underscored: true
});
module.exports = Role;