'use strict';

const { DataTypes, Model } = require('sequelize');
const sequelize = require("./../../database/config/sequelize.js");
const UserValidator = require("./../validators/users.validator.js");
const Role = require("./roles.js")(sequelize, DataTypes);

class User extends Model { }
User.init({
	id: {
		type: DataTypes.INTEGER,
		autoIncrement: true,
		primaryKey: true
	},
	email: {
		type: DataTypes.STRING,
		allowNull: false,
		validate: UserValidator.email
	},
	password: {
		type: DataTypes.STRING,
		validate: UserValidator.password
	},
	roleId: {
		type: DataTypes.INTEGER,
		references: {
			model: Role,
			key: "role_id"
		},
		validate: UserValidator.roleId
	},
	notes: { 
		type: DataTypes.STRING,
		validate: UserValidator.notes
	}
}, {
	sequelize,
	modelName: 'User',
	underscored: true
});

Role.hasMany(User, {as: "users"});
User.belongsTo(Role, {as: "role"});
	
module.exports = User;